// Example product data
const products = [
  { id: 1, name: 'Apple iPhone 15', category: 'Electronics', price: 999, image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Nike Running Shoes', category: 'Footwear', price: 120, image: 'https://via.placeholder.com/150' },
  { id: 3, name: 'Samsung TV', category: 'Electronics', price: 499, image: 'https://via.placeholder.com/150' },
  { id: 4, name: 'Levi’s Jeans', category: 'Clothing', price: 60, image: 'https://via.placeholder.com/150' },
  { id: 5, name: 'Sony Headphones', category: 'Electronics', price: 199, image: 'https://via.placeholder.com/150' },
  { id: 6, name: 'Adidas Sneakers', category: 'Footwear', price: 110, image: 'https://via.placeholder.com/150' },
  { id: 7, name: 'Puma T-shirt', category: 'Clothing', price: 30, image: 'https://via.placeholder.com/150' },
];

export default products;
